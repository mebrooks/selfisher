stopifnot(require("testthat"),
          require("selfisher"))
