## Auto generated - do not edit by hand
.valid_link <- c(
  logit             = 0,
  probit            = 1,
  cloglog           = 2,
  loglog            = 3,
  Richards          = 4
)
.valid_family <- c(
  binomial = 100
)
.valid_covstruct <- c(
  diag = 0,
  us   = 1,
  cs   = 2,
  ar1  = 3,
  ou   = 4,
  exp = 5,
  gau = 6,
  mat = 7,
  toep = 8
)
.valid_ppredictcode <- c(
  response = 0,
  selection = 1,
  prob = 2,
  ratio = 3
)
